### vanilla_droprates

* Updated: Season 9 (patch 2)
* Author: BetweenWalls

Changes all NoDrop rates to vanilla values (TreasureClassEx.txt)

Reduces map monster density by 20% (Levels.txt)