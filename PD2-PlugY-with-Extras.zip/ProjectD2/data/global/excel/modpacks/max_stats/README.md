### max_stats

* Updated: Season 9 (patch 2)
* Author: BetweenWalls

Maximizes all unique/set/runeword attributes, prefixes/suffixes, and armor defense values