### density

* Updated: Season 9 (patch 2)
* Author: BetweenWalls

Multiplies monster density in all areas (different versions for 1.2x, 1.5x, 2x, 3x, 5x, and 10x density)